#ifndef ADDCONTENT
#define ADDCONTENT

#include <stdlib.h>
#include <iostream>

#endif
