#ifndef ADDPEER
#define ADDPEER

#include <stdlib.h>
#include <iostream>
#include <unistd.h>

#endif
