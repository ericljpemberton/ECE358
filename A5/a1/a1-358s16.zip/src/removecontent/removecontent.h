#ifndef REMOVECONTENT
#define REMOVECONTENT

#include <stdlib.h>
#include <iostream>

#endif
