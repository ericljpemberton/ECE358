#ifndef REMOVEPEER
#define REMOVEPEER

#include <stdlib.h>
#include <iostream>

#endif
