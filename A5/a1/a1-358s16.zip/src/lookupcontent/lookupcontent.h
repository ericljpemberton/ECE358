#ifndef LOOKUPCONTENT
#define LOOKUPCONTENT

#include <stdlib.h>
#include <iostream>

#endif
